import argparse
from src.text2sql import Text2SQLPipeline, PipelineConfig

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--schema", default="schema/chinook_pack.yaml")
    ap.add_argument("--sqlite", default="Chinook_Sqlite.sqlite")
    ap.add_argument("--max_rows", type=int, default=50)
    ap.add_argument("question", nargs="*", help="Natural language question")
    args = ap.parse_args()

    q = " ".join(args.question).strip()
    if not q:
        q = "가장 많이 구매한 고객 TOP 5는?"
    cfg = PipelineConfig(schema_pack_path=args.schema, sqlite_path=args.sqlite, max_rows=args.max_rows)
    pipe = Text2SQLPipeline(cfg)
    out = pipe.run(q)
    print(out.get("sql",""))
    if not out.get("ok"):
        print("\n[ERROR]", out.get("error",""))

if __name__ == "__main__":
    main()
