import streamlit as st
import pandas as pd
from src.text2sql import Text2SQLPipeline, PipelineConfig

st.set_page_config(page_title="CHESS-Lite Text-to-SQL", layout="wide")
st.title("🧠 CHESS-Lite Text-to-SQL (MVP)")

schema_path = st.sidebar.text_input("Schema Pack YAML", "schema/chinook_pack.yaml")
sqlite_path = st.sidebar.text_input("SQLite DB path", "Chinook_Sqlite.sqlite")
max_rows = st.sidebar.number_input("Max preview rows", min_value=10, max_value=500, value=50, step=10)

question = st.text_area("질문", "가장 많이 구매한 고객 TOP 5는?")

if st.button("SQL 생성"):
    cfg = PipelineConfig(schema_pack_path=schema_path, sqlite_path=sqlite_path, max_rows=int(max_rows))
    pipe = Text2SQLPipeline(cfg)
    out = pipe.run(question)

    if out.get("ok"):
        st.success("성공")
        st.code(out["sql"], language="sql")
        if out.get("columns") and out.get("preview") is not None:
            df = pd.DataFrame(out["preview"], columns=out["columns"])
            st.dataframe(df, use_container_width=True)
        st.caption(f"선택 테이블: {', '.join(out.get('tables', []))}")
    else:
        st.error("실패")
        st.code(out.get("sql",""), language="sql")
        st.write(out.get("error","")) 
