from __future__ import annotations
from dataclasses import dataclass
from typing import Any, List, Tuple, Optional

@dataclass
class DBResult:
    columns: List[str]
    rows: List[Tuple[Any, ...]]

class DBAdapter:
    dialect: str = "sqlite"

    def execute_preview(self, sql: str) -> DBResult:
        raise NotImplementedError
