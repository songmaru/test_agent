from __future__ import annotations
import sqlite3
from typing import Any, List, Tuple
from .base import DBAdapter, DBResult

class SQLiteAdapter(DBAdapter):
    dialect = "sqlite"

    def __init__(self, path: str):
        self.path = path

    def execute_preview(self, sql: str) -> DBResult:
        conn = sqlite3.connect(self.path)
        cur = conn.cursor()
        cur.execute(sql)
        cols = [d[0] for d in cur.description] if cur.description else []
        rows = cur.fetchmany(50)
        conn.close()
        return DBResult(columns=cols, rows=rows)
