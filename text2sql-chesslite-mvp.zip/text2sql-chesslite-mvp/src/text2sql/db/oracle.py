from __future__ import annotations
# Oracle 어댑터 스켈레톤
# - 회사 환경에 맞는 드라이버(cx_Oracle/oracledb)와 인증 방식을 사용하세요.
# - execute_preview에서는 반드시 row 제한이 걸린 SQL만 실행하도록 가드레일을 유지하세요.

from .base import DBAdapter, DBResult

class OracleAdapter(DBAdapter):
    dialect = "oracle"

    def __init__(self, dsn: str, user: str, password: str):
        self.dsn = dsn
        self.user = user
        self.password = password

    def execute_preview(self, sql: str) -> DBResult:
        raise NotImplementedError("Implement with oracledb/cx_Oracle in your environment")
