from __future__ import annotations
from typing import Dict, List, Tuple, Optional
from collections import deque
from .schema_pack import SchemaPack

def build_adj(pack: SchemaPack) -> Dict[str, List[Tuple[str, str]]]:
    adj: Dict[str, List[Tuple[str, str]]] = {t: [] for t in pack.tables.keys()}
    for t, info in pack.tables.items():
        for e in info.joins:
            if e.to in pack.tables:
                adj[t].append((e.to, e.on))
                # also reverse (best-effort) for path search
                adj[e.to].append((t, e.on))
    return adj

def shortest_join_path(pack: SchemaPack, src: str, dst: str) -> Optional[List[str]]:
    if src == dst:
        return []
    adj = build_adj(pack)
    q = deque([src])
    prev: Dict[str, Tuple[str, str]] = {}
    seen = {src}
    while q:
        cur = q.popleft()
        for nxt, on in adj.get(cur, []):
            if nxt in seen:
                continue
            seen.add(nxt)
            prev[nxt] = (cur, on)
            if nxt == dst:
                q.clear()
                break
            q.append(nxt)
    if dst not in prev:
        return None
    # reconstruct edges as ON clauses in order
    path_nodes = [dst]
    while path_nodes[-1] != src:
        path_nodes.append(prev[path_nodes[-1]][0])
    path_nodes.reverse()
    ons: List[str] = []
    for i in range(1, len(path_nodes)):
        node = path_nodes[i]
        pnode, on = prev[node]
        ons.append(on)
    return ons

def propose_join_hints(pack: SchemaPack, selected: List[str], max_hints: int = 3) -> List[str]:
    hints: List[str] = []
    for i in range(len(selected)):
        for j in range(i+1, len(selected)):
            p = shortest_join_path(pack, selected[i], selected[j])
            if p:
                for on in p:
                    if on not in hints:
                        hints.append(on)
                        if len(hints) >= max_hints:
                            return hints
    return hints
