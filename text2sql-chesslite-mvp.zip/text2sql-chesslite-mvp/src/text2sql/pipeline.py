from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional, Dict, Any
import os
import yaml

from .schema_pack import SchemaPack
from .selector_bm25 import BM25Index
from .join_graph import propose_join_hints
from .prompts import render_schema_snippet, build_generation_prompt, build_repair_prompt
from .llm_ollama import OllamaLLM
from .guardrails import SQLGuard
from .verifier import Verifier, simple_ut
from .db.sqlite import SQLiteAdapter
from .db.base import DBAdapter

@dataclass
class PipelineConfig:
    schema_pack_path: str
    db_dialect: str = "sqlite"
    sqlite_path: str = "Chinook_Sqlite.sqlite"
    max_rows: int = 50
    selector_top_k: int = 8
    repair_rounds: int = 2

class Text2SQLPipeline:
    def __init__(self, cfg: PipelineConfig, db: DBAdapter | None = None):
        self.cfg = cfg
        self.pack = SchemaPack.load(cfg.schema_pack_path)

        # Build BM25
        self.index = BM25Index()
        for t in self.pack.tables.values():
            self.index.add(t.name, self.pack.to_index_text(t))
        self.index.build()

        self.llm = OllamaLLM()

        security_conf = {
            "allowed_statements": ["SELECT"],
            "max_rows": cfg.max_rows,
            "forbidden_keywords": ["DELETE","UPDATE","INSERT","MERGE","DROP","ALTER","TRUNCATE","GRANT","REVOKE"],
        }
        self.guard = SQLGuard(security_conf)

        if db is not None:
            self.db = db
        else:
            # MVP: sqlite만 기본 제공
            self.db = SQLiteAdapter(cfg.sqlite_path)

        self.verifier = Verifier(self.db, self.guard)

    def select_tables(self, question: str) -> List[str]:
        ranked = self.index.search(question, top_k=self.cfg.selector_top_k)
        # score==0인 것은 제거
        tables = [t for t, s in ranked if s > 0]
        return tables[: self.cfg.selector_top_k] if tables else [r[0] for r in ranked[:3]]

    def run(self, question: str) -> Dict[str, Any]:
        selected = self.select_tables(question)
        join_hints = propose_join_hints(self.pack, selected, max_hints=4)

        schema_snippet = render_schema_snippet(self.pack, selected)
        prompt = build_generation_prompt(question, self.db.dialect, self.cfg.max_rows, schema_snippet, join_hints)
        sql = self.llm.generate(prompt)

        # 1) verify
        rep = self.verifier.verify(sql)
        if rep.ok:
            ok, msg = simple_ut(question, rep.sql)
            if ok:
                return {"ok": True, "sql": rep.sql, "tables": selected, "preview": rep.rows_preview, "columns": rep.columns}
            # UT 실패면 수정 루프에 태움
            rep = self.verifier.verify(sql)  # keep

        # 2) repair loop
        error_msg = rep.error or "UT failed"
        for _ in range(self.cfg.repair_rounds):
            rprompt = build_repair_prompt(question, self.db.dialect, self.cfg.max_rows, schema_snippet, join_hints, sql, error_msg)
            sql2 = self.llm.generate(rprompt)
            rep2 = self.verifier.verify(sql2)
            if rep2.ok:
                ok, msg = simple_ut(question, rep2.sql)
                if ok:
                    return {"ok": True, "sql": rep2.sql, "tables": selected, "preview": rep2.rows_preview, "columns": rep2.columns}
                error_msg = "UT: " + msg
                sql = sql2
                continue
            error_msg = rep2.error
            sql = sql2

        return {"ok": False, "sql": sql, "tables": selected, "error": error_msg}
