from __future__ import annotations
import os
from langchain_ollama import ChatOllama
from langchain_core.messages import HumanMessage

class OllamaLLM:
    def __init__(self, model: str | None = None, temperature: float = 0.1):
        self.model = model or os.getenv("OLLAMA_MODEL", "qwen3:4b")
        self.client = ChatOllama(model=self.model, temperature=temperature)

    def generate(self, prompt: str) -> str:
        msg = HumanMessage(content=prompt)
        resp = self.client.invoke([msg])
        text = getattr(resp, "content", "") or ""
        return text.strip()
