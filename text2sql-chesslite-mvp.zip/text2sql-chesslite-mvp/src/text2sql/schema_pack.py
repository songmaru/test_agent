from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
import yaml

@dataclass
class JoinEdge:
    to: str
    on: str
    type: str = "inner"

@dataclass
class ColumnInfo:
    name: str
    desc: str = ""
    type: str = ""

@dataclass
class TableInfo:
    name: str
    desc: str = ""
    grain: str = ""
    tags: List[str] = field(default_factory=list)
    pk: List[str] = field(default_factory=list)
    joins: List[JoinEdge] = field(default_factory=list)
    columns: List[ColumnInfo] = field(default_factory=list)
    synonyms: Dict[str, List[str]] = field(default_factory=dict)
    question_examples: List[str] = field(default_factory=list)

@dataclass
class SchemaPack:
    domain: str
    tables: Dict[str, TableInfo]

    @staticmethod
    def load(path: str) -> "SchemaPack":
        with open(path, "r", encoding="utf-8") as f:
            obj = yaml.safe_load(f)
        domain = obj.get("domain", "unknown")
        tables: Dict[str, TableInfo] = {}
        for t in obj.get("tables", []):
            joins = [JoinEdge(**j) for j in t.get("joins", [])]
            cols = [ColumnInfo(**c) for c in t.get("columns", [])]
            ti = TableInfo(
                name=t["name"],
                desc=t.get("desc", ""),
                grain=t.get("grain", ""),
                tags=t.get("tags", []) or [],
                pk=t.get("pk", []) or [],
                joins=joins,
                columns=cols,
                synonyms=t.get("synonyms", {}) or {},
                question_examples=t.get("question_examples", []) or [],
            )
            tables[ti.name] = ti
        return SchemaPack(domain=domain, tables=tables)

    def to_index_text(self, table: TableInfo) -> str:
        parts = [table.name, table.desc, table.grain, " ".join(table.tags)]
        for c in table.columns:
            parts.append(f"{c.name} {c.desc}")
        for k, vs in (table.synonyms or {}).items():
            parts.append(k)
            parts.extend(vs)
        parts.extend(table.question_examples or [])
        return "\n".join([p for p in parts if p])
