from __future__ import annotations
from typing import Dict
import re
import sqlglot

class SQLGuard:
    def __init__(self, security_conf: Dict):
        self.allowed_statements = set(security_conf.get("allowed_statements", ["SELECT"]))
        self.max_rows = int(security_conf.get("max_rows", 50))
        self.forbidden_keywords = set([kw.upper() for kw in security_conf.get("forbidden_keywords", [])])

    def validate_select_only(self, sql: str):
        upper = sql.upper()
        for kw in self.forbidden_keywords:
            if re.search(rf"\b{re.escape(kw)}\b", upper):
                raise ValueError(f"Forbidden keyword detected: {kw}")
        parsed = sqlglot.parse_one(sql, error_level="RAISE")
        if parsed is None:
            raise ValueError("Failed to parse SQL")
        if parsed.key != "select":
            raise ValueError("Only SELECT is allowed")
        return parsed

    def enforce_row_limit(self, sql: str, dialect: str) -> str:
        # Best-effort: append limit if absent
        upper = sql.upper()
        if dialect == "oracle":
            if "FETCH FIRST" in upper or "ROWNUM" in upper:
                return sql
            return f"SELECT * FROM (\n{sql}\n) WHERE ROWNUM <= {self.max_rows}"
        else:
            if " LIMIT " in upper:
                return sql
            return f"{sql.rstrip(';')} LIMIT {self.max_rows}"
