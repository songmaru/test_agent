import re
from typing import List

_TOKEN_RE = re.compile(r"[A-Za-z0-9가-힣_]+")

def tokenize(text: str) -> List[str]:
    return [m.group(0).lower() for m in _TOKEN_RE.finditer(text or "")]
