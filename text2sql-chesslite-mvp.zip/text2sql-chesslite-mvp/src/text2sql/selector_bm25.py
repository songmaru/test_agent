from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Tuple
import math
from .text import tokenize

@dataclass
class BM25Doc:
    doc_id: str
    text: str
    tokens: List[str]

class BM25Index:
    def __init__(self, k1: float = 1.6, b: float = 0.75):
        self.k1 = k1
        self.b = b
        self.docs: List[BM25Doc] = []
        self.df: Dict[str, int] = {}
        self.avgdl = 0.0

    def add(self, doc_id: str, text: str):
        toks = tokenize(text)
        self.docs.append(BM25Doc(doc_id=doc_id, text=text, tokens=toks))
        seen = set(toks)
        for t in seen:
            self.df[t] = self.df.get(t, 0) + 1

    def build(self):
        if not self.docs:
            self.avgdl = 0.0
            return
        self.avgdl = sum(len(d.tokens) for d in self.docs) / len(self.docs)

    def _idf(self, term: str) -> float:
        # BM25+ like smoothing
        n = len(self.docs)
        df = self.df.get(term, 0)
        return math.log(1 + (n - df + 0.5) / (df + 0.5))

    def search(self, query: str, top_k: int = 10) -> List[Tuple[str, float]]:
        q = tokenize(query)
        if not q or not self.docs:
            return []
        scores: List[Tuple[str, float]] = []
        for d in self.docs:
            dl = len(d.tokens)
            tf: Dict[str, int] = {}
            for t in d.tokens:
                tf[t] = tf.get(t, 0) + 1
            score = 0.0
            for term in q:
                if term not in tf:
                    continue
                idf = self._idf(term)
                freq = tf[term]
                denom = freq + self.k1 * (1 - self.b + self.b * (dl / (self.avgdl or 1.0)))
                score += idf * (freq * (self.k1 + 1)) / (denom or 1.0)
            scores.append((d.doc_id, score))
        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:top_k]
