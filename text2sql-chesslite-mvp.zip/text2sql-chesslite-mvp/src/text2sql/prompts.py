from __future__ import annotations
from typing import List
from .schema_pack import SchemaPack

def render_schema_snippet(pack: SchemaPack, table_names: List[str]) -> str:
    lines = []
    for tname in table_names:
        t = pack.tables[tname]
        lines.append(f"- {t.name}: {t.desc}")
        # 대표 컬럼 5~15개만
        for c in t.columns[:15]:
            lines.append(f"  - {c.name}: {c.desc}")
    return "\n".join(lines)

def system_rules(dialect: str, max_rows: int) -> str:
    # 약한 LLM일수록 규칙을 짧고 강하게
    if dialect == "oracle":
        limit_rule = f"결과가 많을 수 있으면 반드시 FETCH FIRST {max_rows} ROWS ONLY 또는 ROWNUM 제한을 포함하세요."
        date_rule = "Oracle 날짜는 DATE/TIMESTAMP 타입을 고려하고, 필요한 경우 TO_DATE/TO_TIMESTAMP를 사용하세요."
    else:
        limit_rule = f"결과가 많을 수 있으면 반드시 LIMIT {max_rows} 를 포함하세요."
        date_rule = "날짜 컬럼은 문자열 비교가 아니라 날짜 타입에 맞게 처리하세요."
    return "\n".join([
        "당신은 Text-to-SQL 엔진입니다.",
        "출력은 오직 SQL 한 덩어리만 반환하세요. 설명/마크다운/코드펜스 금지.",
        "허용되는 문장은 SELECT 한 종류입니다.",
        limit_rule,
        date_rule,
        "테이블/컬럼은 제공된 스키마 범위 내에서만 사용하세요.",
    ])

def build_generation_prompt(question: str, dialect: str, max_rows: int, schema_snippet: str, join_hints: List[str]) -> str:
    joins = "\n".join([f"- {j}" for j in join_hints]) if join_hints else "(없음)"
    return f"""{system_rules(dialect, max_rows)}

[선택된 스키마]
{schema_snippet}

[조인 힌트(참고)]
{joins}

[질문]
{question}

SQL:"""

def build_repair_prompt(question: str, dialect: str, max_rows: int, schema_snippet: str, join_hints: List[str], prev_sql: str, error_msg: str) -> str:
    joins = "\n".join([f"- {j}" for j in join_hints]) if join_hints else "(없음)"
    return f"""{system_rules(dialect, max_rows)}

[선택된 스키마]
{schema_snippet}

[조인 힌트(참고)]
{joins}

[질문]
{question}

[이전 SQL]
{prev_sql}

[DB 에러]
{error_msg}

위 에러를 해결하도록 SQL을 수정하세요. 출력은 SQL만.
SQL:"""
