from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Dict, Any, Tuple
import re
from .guardrails import SQLGuard
from .db.base import DBAdapter, DBResult

@dataclass
class VerifyReport:
    ok: bool
    error: str = ""
    sql: str = ""
    columns: list[str] | None = None
    rows_preview: list[tuple] | None = None

def simple_ut(question: str, sql: str) -> Tuple[bool, str]:
    q = question.lower()
    s = sql.lower()

    agg_kw = ["평균", "합계", "총", "개수", "count", "sum", "avg"]
    group_hint = ["별", "by "]
    top_hint = ["top", "상위", "최대", "topn"]
    time_hint = ["최근", "지난", "기간", "between", "from", "to", "월", "주", "년", "date"]

    if any(k in q for k in agg_kw) and not any(k in s for k in ["count(", "sum(", "avg("]):
        return False, "집계 의도인데 집계 함수가 보이지 않습니다."
    if any(k in q for k in group_hint) and "group by" not in s:
        return False, "'~별' 의도인데 GROUP BY가 보이지 않습니다."
    if any(k in q for k in top_hint) and not ("order by" in s):
        return False, "Top/상위 의도인데 ORDER BY가 보이지 않습니다."
    if any(k in q for k in time_hint) and not any(k in s for k in ["where", "between", "to_date", "strftime"]):
        return False, "기간/시간 의도인데 WHERE/기간조건이 약합니다."
    return True, ""

class Verifier:
    def __init__(self, db: DBAdapter, guard: SQLGuard):
        self.db = db
        self.guard = guard

    def verify(self, sql: str) -> VerifyReport:
        try:
            self.guard.validate_select_only(sql)
            safe_sql = self.guard.enforce_row_limit(sql, self.db.dialect)
            res: DBResult = self.db.execute_preview(safe_sql)
            return VerifyReport(ok=True, sql=safe_sql, columns=res.columns, rows_preview=res.rows)
        except Exception as e:
            return VerifyReport(ok=False, sql=sql, error=str(e))
