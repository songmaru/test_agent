# CHESS-Lite Text-to-SQL (Oracle/SQLite) — 비용 최적화 MVP

이 프로젝트는 **대형 Oracle 환경 + 약한 LLM(qwen3)** 조건에서 Text-to-SQL을 안정적으로 만들기 위해,
CHESS 철학(검색/컨텍스트 수집 → 스키마 축소 → 후보 생성 → 검증/수정 루프)을 **저비용으로 단순화**한 MVP입니다.

## 핵심 특징
- **Schema Pack(YAML)**: 수기 작성량 최소화(테이블 한줄 설명 + 핵심 컬럼 + 조인 + 동의어/예시)
- **Selector(LLM 없이)**: BM25로 관련 테이블 Top-K 선택
- **LLM(qwen3/Ollama)**: 선택된 스키마만 넣어 SQL 생성
- **Verifier**: sqlglot + 실행(미리보기) + 규칙 기반 UT로 안전하게 검증 후 자동 수정

## 빠른 시작 (SQLite 데모)
```bash
pip install -r requirements.txt
streamlit run app_streamlit.py
```

## Oracle 연결 (스켈레톤)
Oracle 실행은 `src/text2sql/db/oracle.py`에 어댑터만 구현하면 됩니다.
- 보안/성능상 **검증 실행은 반드시 row 제한(FETCH/ROWNUM)** 을 강제하세요.

## 환경 변수
- `OLLAMA_MODEL` (기본: `qwen3:4b`)
- `DB_DIALECT` (기본: `sqlite` / oracle 지원 예정)
- `SQL_MAX_ROWS` (기본: 50)

## 폴더 구조
- `src/text2sql/` : 코어 파이프라인
- `schema/` : Schema Pack YAML
- `examples/` : 샘플 질문
